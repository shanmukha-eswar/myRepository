package com.AttendanceMarking.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AttendanceMarking.model.Admin;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.Trainer;
import com.AttendanceMarking.model.User;
import com.AttendanceMarking.service.AdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin("http://localhost:4200")
public class AdminController {

	@Autowired
	AdminService service;
	
	@GetMapping("/getAdminDetails/{adminId}")
	public List<Admin> getAdminDetails(@PathVariable("adminId")int adminId){
		return service.getAdminDetails(adminId);
	}

	@GetMapping("/adminRegistration/{firstName}/{lastName}/{age}/{gender}/{contactNumber}/{loginId}/{password}/{q1}/{q2}/{q3}/{defaultId}")
	public List<String> registerUser(@PathVariable("firstName") String firstName,
			@PathVariable("lastName") String lastName, @PathVariable("age") int age,
			@PathVariable("gender") String gender, @PathVariable("contactNumber") String contactNumber,
			@PathVariable("loginId") String loginId, @PathVariable("password") String password,
			@PathVariable("q1") String question1, @PathVariable("q2") String question2,
			@PathVariable("q3") String question3, @PathVariable("defaultId") String defaultId) {
		Admin admin = new Admin(firstName, lastName, age, gender, contactNumber, question1, question2, question3);
		int correspondingId = service.registerAdmin(admin, defaultId);
		System.out.println("Returned:" + correspondingId);
		LoginDetails loginDetails = new LoginDetails();
		loginDetails.setLoginId(loginId);
		loginDetails.setPassword(password);
		loginDetails.setAccountType("admin");
		loginDetails.setCorrespondingId(correspondingId);
		service.saveLoginDetails(loginDetails);
		List<String> result = new ArrayList<String>();
		result.add("success");

		return result;
	}

	@GetMapping("/skillsets")
	public List<SkillSet> getSkillSets() {
		return service.getSkillSets();
	}

	@GetMapping("/trainers")
	public List<Trainer> getTrainers() {
		return service.getTrainers();
	}

	@GetMapping("/sessions/{id}")
	public List<Session> getSessions(@PathVariable("id") int adminId) {
		return service.getSessionsOfAdmin(adminId);
	}

	@GetMapping("/getSessionsBySkillType/{skillType}")
	public List<Session> getSessionsBySkillType(@PathVariable("skillType") String skill) {
		return service.getSessionBySkillType(skill);
	}

	@GetMapping("/addSession/{description}/{date}/{slot}/{skill}/{trainerName}/{adminId}/{trainerId}/{sessionId}")
	public List<String> addSession(@PathVariable("description") String description, @PathVariable("date") String date,
			@PathVariable("slot") String slot, @PathVariable("skill") String skill,
			@PathVariable("trainerName") String trainerName, @PathVariable("adminId") int adminId,
			@PathVariable("trainerId") int trainerId, @PathVariable("sessionId") int sessionId) {
		List<String> list = new ArrayList<String>();
		if (sessionId == 0) {

			Session session = new Session();
			session.setSessionDescription(description);
			try {
				session.setSessionDate(new SimpleDateFormat("yyyy-MM-dd").parse(date));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			session.setSlot(slot);
			session.setSkillType(skill);
			session.setTrainerName(trainerName);
			System.out.println(session.getSessionDate());
			System.out.println(adminId);
			System.out.println(trainerId);
			if (service.addSession(session, adminId)
					&& service.addTrainerAllocation(trainerId, session.getSessionDate(), slot)) {
				list.add("success");
			} else {
				list.add("failed");
			}
		} else {
			Session session = new Session();
			session.setSessionId(sessionId);
			session.setSessionDescription(description);
//			System.out.println(date.substring(0, 9));
			try {
				session.setSessionDate(new SimpleDateFormat("yyyy-MM-dd").parse(date.substring(0, 10)));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			session.setSlot(slot);
			session.setSkillType(skill);
			session.setTrainerName(trainerName);
			System.out.println(session.getTrainerName());
			if (service.updateSession(session)) {
				list.add("success");
			} else {
				list.add("failed");
			}

		}
		return list;
	}

	@GetMapping("/availableTrainers/{date}/{slot}/{skill}")
	public List<Trainer> getAvailableTrainers(@PathVariable("date") String date, @PathVariable("slot") String slot,
			@PathVariable("skill") String skill) {
		return service.getAvailableTrainers(date, slot, skill);
	}

	@GetMapping("/addTrainer/{trainerName}/{contactNumber}/{email}/{skill}/{trainerId}")
	public List<String> addTrainer(@PathVariable("trainerName") String trainerName,
			@PathVariable("contactNumber") String contactNumber, @PathVariable("email") String email,
			@PathVariable("skill") String skill, @PathVariable("trainerId") int trainerId) {
		List<String> list = new ArrayList<String>();
		Trainer trainer = new Trainer();
		trainer.setTrainerId(trainerId);
		trainer.setTrainerName(trainerName);
		trainer.setContactNumber(contactNumber);
		trainer.setEmail(email);
		trainer.setSkillType(skill);

		if (trainerId == 0) {
			if (service.addTrainer(trainer)) {
				list.add("success");
			} else {
				list.add("failed");
			}
		} else {
			if (service.updateTrainer(trainer)) {
				list.add("success");
			} else {
				list.add("failed");
			}
		}
		return list;

	}

	@GetMapping("/addSkillSet/{skillType}/{description}")
	public List<String> addSkillSet(@PathVariable("skillType") String skillType,
			@PathVariable("description") String skillDescription) {
		List<String> list = new ArrayList<String>();
		SkillSet skill = new SkillSet();
		skill.setSkillType(skillType);
		skill.setSkillDescription(skillDescription);
		if (service.addSkillSet(skill)) {
			list.add("success");
		}
		return list;
	}

	@GetMapping("delete/{name}/{id}")
	public List<String> deleteThings(@PathVariable("name") String name, @PathVariable("id") int id) {
		List<String> list = new ArrayList<String>();
		switch (name) {
			case "session": {
				if(service.deleteSession(id)) { list.add("success");}
				break;
			}
			case "trainer": {
				if(service.deleteTrainer(id)) { list.add("success");}
				break;
			}
			case "skillset": {
				if(service.deleteSkillSet(id)) { list.add("success");}
				break;
			}
		}
		return list;
	}
	
	@GetMapping("getEnrolledUsers/{sessionId}")
	public List<User> getRegisteredUsers(@PathVariable("sessionId")int sessionId){
		return service.getRegisteredUsers(sessionId);
	}
	
	
	@GetMapping("getAttendedUsers/{sessionId}")
	public List<User> getAteendedUsers(@PathVariable("sessionId")int sessionId){
		return service.getAttendedUsersOfSession(sessionId);
	}

}