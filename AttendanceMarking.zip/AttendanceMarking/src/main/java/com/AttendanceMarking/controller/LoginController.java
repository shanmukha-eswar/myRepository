package com.AttendanceMarking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.service.LoginService;

@RestController
@CrossOrigin("http://localhost:4200")
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	@GetMapping("/login")
	public List<LoginDetails> getLoginDetails(){
		return service.getLoginDetails();
	}
	
	@GetMapping("/fetchDetails/{email}")
	public List<String> fetchDetails(@PathVariable("email")String email){
		return service.fetchDetails(email);
	}
	
	@GetMapping("/resetPassword/{loginId}/{password}")
	public List<String> resetPassword(@PathVariable("loginId")String loginId,@PathVariable("password")String password) {
		List<String> list=new ArrayList<String>();
		service.resetPassword(loginId, password);
		list.add("success");
		return list;
		
	}
	
	@GetMapping("/getAdminLoginIds")
	public List<String> getAdminLoginIds(){
		return service.getAdminLoginIds();
	}
	
	@GetMapping("/addAdminLoginId/{loginId}")
	public List<String> addAdminLoginId(@PathVariable("loginId")String loginId) {
		List<String> list=new ArrayList<String>();
		service.addAdminLoginId(loginId);
		list.add("success");
		return list;
	}
}
