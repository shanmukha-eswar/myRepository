package com.AttendanceMarking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.User;
import com.AttendanceMarking.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin("http://localhost:4200")
public class UserController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/getUserDetails/{userId}")
	public List<User> getUserDetails(@PathVariable("userId")int userId){
		return service.getUserDetails(userId);
	}
	
	@GetMapping("/userRegistration/{firstName}/{lastName}/{email}/{loginId}/{password}/{q1}/{q2}/{q3}")
	public List<String> registerUser(@PathVariable("firstName")String firstName,
								@PathVariable("lastName")String lastName,
								@PathVariable("email")String email,
								@PathVariable("loginId")String loginId,
								@PathVariable("password")String password,
								@PathVariable("q1")String question1,
								@PathVariable("q2")String question2,
								@PathVariable("q3")String question3)
	{
		User user=new User(firstName,lastName,email,question1,question2,question3);
		int correspondingId=service.registerUser(user);
		System.out.println("Returned:"+ correspondingId);
		LoginDetails loginDetails=new LoginDetails();
		loginDetails.setLoginId(loginId);
		loginDetails.setPassword(password);
		loginDetails.setAccountType("user");
		loginDetails.setCorrespondingId(correspondingId);
		service.saveLoginDetails(loginDetails);
		List<String> result=new ArrayList<String>();
		result.add("success");
		
		return result;
	}
	
	@GetMapping("/availableSessions")
	public List<Session> test(){
		return service.getAvailableSessions();
	}
	
	@GetMapping("/getSessionsBySkillType/{skillType}")
	public List<Session> getSessionsBySkillType(@PathVariable("skillType")String skill){
		return service.getSessionBySkillType(skill);
	}
	
	@GetMapping("/getSkillSets")
	public List<SkillSet> getSkillSets(){
		return service.getSkillSets();
	}
	
	@GetMapping("/enroll/{sessionId}/{userId}")
	public List<String> enrollUser(@PathVariable("sessionId")int sessionId,@PathVariable("userId")int userId){
		List<String> list=new ArrayList<String>();
		service.enrollUser(sessionId, userId);
		list.add("success");
		return list;
	}

	@GetMapping("/getEnrolledSessions/{userId}")
	public List<Session> getEnrolledSessions(@PathVariable("userId")int userId){
		return service.getRegisteredSessions(userId);
	}
	
	
	@GetMapping("/join/{sessionId}/{userId}")
	public List<String> joinSession(@PathVariable("sessionId")int sessionId,@PathVariable("userId")int userId){
		List<String> list=new ArrayList<String>();
		service.joinSession(userId, sessionId);
		list.add("success");
		return list;
	}
	
	@GetMapping("/getAttendedSessions/{userId}")
	public List<Session> getAttendedSessions(@PathVariable("userId")int userId){
		return service.getAttendedSessions(userId);
	}
}
