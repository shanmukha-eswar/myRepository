package com.AttendanceMarking.dao;

import java.util.Date;
import java.util.List;

import com.AttendanceMarking.model.Admin;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.Trainer;
import com.AttendanceMarking.model.User;

public interface Dao {
	
	public List<LoginDetails> getLoginDetails(); //implimented
	public List<Session> getSessions(); //implimented
	public List<Session> getSessionsOfAdmin(int adminId); //implimented
	public List<Trainer> getTrainers(); //implimented
	public List<Trainer> getAvailableTrainers(String date, String slot, String skill); //implimented
	public List<SkillSet> getSkillsets(); //implimented
	public List<User> getAttendedUsersOfSession(int sessionId); //implimented
	public boolean addSession(Session session, int admin_id); //implimented
	public boolean updateSession(Session session); //implemented
	public boolean deleteSession(int sessionId); //implemented
	public boolean addTrainer(Trainer trainer); //implimented
	public boolean updateTrainer(Trainer trainer); //implemented
	public boolean deleteTrainer(int trainerId); //implemented
	public boolean addSkillSet(SkillSet skill); //implimented
	public boolean deleteSkillSet(int skillsetId); //implemented
	public boolean addTrainerAllocation(int trainerId, Date date, String slot); //implimented
	public int saveUser(User user); //implimented
	public int saveAdmin(Admin admin, String loginId); //implimented
	public void saveLoginDetails(LoginDetails loginDetails); //implimented
	public List<Session> getSessionBySkillType(String skillType); //implimented
	public void enrollUser (int userId,int sessionId); //implimented
	public List<Session> getRegisteredSessions(int userId); //implimented
	public void joinSession (int userId,int sessionId); //implimented
	public List<Session> getAttendedSessions(int userId); //implimented
	public List<User> getRegisteredUsers(int sessionId); //implimented
	public List<String> fetchDetails(String email); //implimented
	public void resetPassword(String loginId, String password); //implimented
	public List<Admin> getAdminDetails(int adminId); //implimented
	public List<User> getUserDetails(int userId); //implimented
	public List<String> getAdminLoginIds(); //implimented
	public void addAdminLoginId(String loginId); //implimented
}
