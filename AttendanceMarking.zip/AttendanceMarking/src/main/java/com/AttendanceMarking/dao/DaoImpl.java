package com.AttendanceMarking.dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import com.AttendanceMarking.model.Admin;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.Trainer;
import com.AttendanceMarking.model.User;

@Component
public class DaoImpl implements Dao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	// Returns all loginDetails from database login_details table
	@Override
	public List<LoginDetails> getLoginDetails() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from login_details", new ResultSetExtractor<List<LoginDetails>>() {

			@Override
			public List<LoginDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<LoginDetails> list = new ArrayList<LoginDetails>();
				while (rs.next()) {
					LoginDetails loginDetails = new LoginDetails();
					loginDetails.setLoginId(rs.getString(1));
					loginDetails.setPassword(rs.getString(2));
					loginDetails.setAccountType(rs.getString(3));
					loginDetails.setCorrespondingId(rs.getInt(4));
					list.add(loginDetails);
				}
				return list;
			}
		});
	}

	@Override
	public List<Session> getSessions() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from session_details where session_id not in(select session_id from session_enrollment)", new ResultSetExtractor<List<Session>>() {

			@Override
			public List<Session> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Session> list = new ArrayList<Session>();
				while (rs.next()) {
					Session session = new Session();
					session.setSessionId(rs.getInt(1));
					session.setSessionDescription(rs.getString(2));
					session.setSessionDate(new Date(rs.getDate(3).getTime()));
					session.setSlot(rs.getString(4));
					session.setTrainerName(rs.getString(5));
					session.setSkillType(rs.getString(6));
					char[] ch = new char[1];
					try {
						rs.getCharacterStream(7).read(ch);
					} catch (IOException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					session.setIs_completed(ch[0]);
					list.add(session);
				}

				return list;
			}
		});
	}

	@Override
	public List<Session> getSessionsOfAdmin(int adminId) {
		// TODO Auto-generated method stub
		String sql = "select * from session_details where admin_id=" + adminId;
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<Session>>() {

			@Override
			public List<Session> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Session> list = new ArrayList<Session>();
				while (rs.next()) {
					Session session = new Session();
					session.setSessionId(rs.getInt(1));
					session.setSessionDescription(rs.getString(2));
					session.setSessionDate(new Date(rs.getDate(3).getTime()+86400000));
					session.setSlot(rs.getString(4));
					session.setTrainerName(rs.getString(5));
					session.setSkillType(rs.getString(6));
					char[] ch = new char[1];
					try {
						rs.getCharacterStream(7).read(ch);
					} catch (IOException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					session.setIs_completed(ch[0]);
					list.add(session);
					

				}
				return list;
			}
		});
	}

	@Override
	public List<Trainer> getTrainers() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from trainer_details", new ResultSetExtractor<List<Trainer>>() {

			@Override
			public List<Trainer> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Trainer> list = new ArrayList<Trainer>();
				while (rs.next()) {
					Trainer trainer = new Trainer();
					trainer.setTrainerId(rs.getInt(1));
					trainer.setTrainerName(rs.getString(2));
					trainer.setContactNumber(rs.getString(3));
					trainer.setEmail(rs.getString(4));
					trainer.setSkillType(rs.getString(5));
					list.add(trainer);
				}

				return list;
			}
		});
	}

	@Override
	public List<SkillSet> getSkillsets() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from skillset_details", new ResultSetExtractor<List<SkillSet>>() {

			@Override
			public List<SkillSet> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<SkillSet> list = new ArrayList<SkillSet>();
				while (rs.next()) {
					SkillSet skill = new SkillSet();
					skill.setSkillId(rs.getInt(1));
					skill.setSkillType(rs.getString(2));
					skill.setSkillDescription(rs.getString(3));
					list.add(skill);
					//System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));
				}
				return list;
			}
		});
	}

	@Override
	public List<User> getAttendedUsersOfSession(int sessionId) {
		// TODO Auto-generated method stub
		String sql="select * from user_details where employee_id in(select user_id from session_attendance where session_id="+sessionId+")";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<User>>() {

			@Override
			public List<User> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<User> list=new ArrayList<User>();
				while(rs.next()) {
					User user=new User();
					user.setEmployee_id(rs.getInt(1));
					user.setFirstName(rs.getString(2));
					user.setLastName(rs.getString(3));
					user.setEmail(rs.getString(4));
					user.setQuestion1(rs.getString(5));
					user.setQuestion2(rs.getString(6));
					user.setQuestion3(rs.getString(7));
					list.add(user);
				}
				
				return list;
			}});
	}

	@Override
	public boolean addSession(Session session, int adminId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.execute("insert into session_details(session_description,session_date,slot,trainer_name,skill_type,is_completed,admin_id)"
				+ " values(?, str_to_date(?,'%d-%m-%Y'),?,?,?,?,?)",
				new PreparedStatementCallback<Boolean>() {

					@Override
					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ps.setString(1, session.getSessionDescription());
						ps.setString(2, new SimpleDateFormat("dd-MM-yyyy").format(session.getSessionDate()));
						ps.setString(3, session.getSlot());
						ps.setString(4, session.getTrainerName());
						ps.setString(5, session.getSkillType());
						ps.setString(6, "N");
						ps.setInt(7, adminId);
						try {
							ps.execute();
							return true;
						}
						catch(SQLException e) {
							return false;
						}
					}});
	}

	@Override
	public boolean updateSession(Session session) {
		// TODO Auto-generated method stub
		String sql="update session_details set session_description='"+session.getSessionDescription()+"', session_date=str_to_date('"+new SimpleDateFormat("dd-MM-yyyy").format(session.getSessionDate())+"','%d-%m-%Y'), slot='"+session.getSlot()+"', trainer_name='"+session.getTrainerName()+"',skill_type='"+session.getSkillType()+"' where session_id="+session.getSessionId();
		if(jdbcTemplate.update(sql)==1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean addTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		
		jdbcTemplate.execute("insert into trainer_details(trainer_name, contact_number, email, skill_type) values(?,?,?,?)", new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				ps.setString(1, trainer.getTrainerName());
				ps.setString(2, trainer.getContactNumber());
				ps.setString(3, trainer.getEmail());
				ps.setString(4, trainer.getSkillType());
				
				return ps.execute();
			}});
		return true;
	}

	@Override
	public boolean updateTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		String sql="update trainer_details set trainer_name='"+trainer.getTrainerName()+"',contact_number='"+trainer.getContactNumber()+"',email='"+trainer.getEmail()+"',skill_type='"+trainer.getSkillType()+"' where trainer_id="+trainer.getTrainerId();
		if(jdbcTemplate.update(sql)==1) {
			return true;
		}
		
		return false;
	}

	@Override
	public boolean addSkillSet(SkillSet skill) {
		// TODO Auto-generated method stub
		String sql="insert into skillset_details(skill_type, skill_description) values('"+skill.getSkillType()+"','"+skill.getSkillDescription()+"')";
		jdbcTemplate.execute(sql);
		return true;
	}


	@Override
	public int saveUser(User user) {
		// TODO Auto-generated method stub
		jdbcTemplate.execute(
				"insert into user_details(first_name, last_name, email, question1, question2, question3) values(?,?,?,?,?,?)",
				new PreparedStatementCallback<Boolean>() {

					@Override
					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ps.setString(1, user.getFirstName());
						ps.setString(2, user.getLastName());
						ps.setString(3, user.getEmail());
						ps.setString(4, user.getQuestion1());
						ps.setString(5, user.getQuestion2());
						ps.setString(6, user.getQuestion3());
						return ps.execute();
					}
				});
		return jdbcTemplate.query(
				"select * from user_details where employee_id=(select max(employee_id) from user_details)",
				new ResultSetExtractor<Integer>() {

					@Override
					public Integer extractData(ResultSet rs) throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						while (rs.next()) {
							return rs.getInt("employee_id");
						}
						return null;
					}
				});
	}

	@Override
	public int saveAdmin(Admin admin, String loginId) {
		// TODO Auto-generated method stub

		jdbcTemplate.execute("delete from login_details where login_id=?", new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				ps.setString(1, loginId);
				return ps.execute();
			}
		});

		jdbcTemplate.execute(
				"insert into admin_details(first_name, last_name, age, gender, contact_number, question1, question2, question3) values(?,?,?,?,?,?,?,?)",
				new PreparedStatementCallback<Boolean>() {

					@Override
					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ps.setString(1, admin.getFirstName());
						ps.setString(2, admin.getLastName());
						ps.setInt(3, admin.getAge());
						ps.setString(4, admin.getGender());
						ps.setString(5, admin.getContactNumber());
						ps.setString(6, admin.getQuestion1());
						ps.setString(7, admin.getQuestion2());
						ps.setString(8, admin.getQuestion3());
						return ps.execute();
					}
				});
		return jdbcTemplate.query(
				"select * from admin_details where admin_id=(select max(admin_id) from admin_details)",
				new ResultSetExtractor<Integer>() {

					@Override
					public Integer extractData(ResultSet rs) throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						while (rs.next()) {
							return rs.getInt("admin_id");
						}
						return null;
					}
				});
	}

	@Override
	public void saveLoginDetails(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		jdbcTemplate.execute("insert into login_details values(?,?,?,?)", new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				ps.setString(1, loginDetails.getLoginId());
				ps.setString(2, loginDetails.getPassword());
				ps.setString(3, loginDetails.getAccountType());
				ps.setInt(4, loginDetails.getCorrespondingId());
				ps.execute();
				return null;
			}
		});

	}

	@Override
	public List<Trainer> getAvailableTrainers(String date, String slot1, String skill) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from trainer_allocation", new ResultSetExtractor<List<Trainer>>() {

			@Override
			public List<Trainer> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				String ids="";
				while(rs.next()) {
					String trainerId=String.valueOf(rs.getInt(1));
					String sessionDate=rs.getDate(2).toString();
					String slot2=rs.getString(3);
					//System.out.println("trinerId: "+trainerId+" session date: "+sessionDate+" slot: "+slot2);
					
					if(sessionDate.equals(date) && slot1.equals(slot2)) {
						if(ids.equals("")) {
							ids=ids+trainerId;
						}
						else {
							ids=ids+","+trainerId;
						}
					}
					//System.out.println(ids);
				}
				String sql="select * from trainer_details where trainer_id not in "+"("+ids+")"+" and skill_type='"+skill+"'";
				if(ids.equals("")) {
					sql="select * from trainer_details where skill_type='"+skill+"'";
				}
				//System.out.println(sql);
				return jdbcTemplate.query(sql, new ResultSetExtractor<List<Trainer>>() {

					@Override
					public List<Trainer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						List<Trainer> list = new ArrayList<Trainer>();
						while (rs.next()) {
							Trainer trainer = new Trainer();
							trainer.setTrainerId(rs.getInt(1));
							trainer.setTrainerName(rs.getString(2));
							trainer.setContactNumber(rs.getString(3));
							trainer.setEmail(rs.getString(4));
							trainer.setSkillType(rs.getString(5));
							list.add(trainer);
						}
						return list;
					}
				});
			}});
	}

	@Override
	public boolean addTrainerAllocation(int trainerId, Date date, String slot) {
		// TODO Auto-generated method stub
		String sql="insert into trainer_allocation values("+trainerId+", str_to_date('"+new SimpleDateFormat("dd-MM-yyyy").format(date)+"','%d-%m-%Y'), '"+slot+"')";
		System.out.println(sql);
		jdbcTemplate.execute(sql);
		return true;
	}

	@Override
	public List<Session> getSessionBySkillType(String skillType) {
		// TODO Auto-generated method stud
		
		 String sql="SELECT * FROM session_details WHERE skill_type='"+skillType+"'";
		 return jdbcTemplate.query(sql, new ResultSetExtractor<List<Session>>() {

				@Override
				public List<Session> extractData(ResultSet rs) throws SQLException, DataAccessException {
					// TODO Auto-generated method stub
					List<Session> list = new ArrayList<Session>();
					while (rs.next()) {
						Session session = new Session();
						session.setSessionId(rs.getInt(1));
						session.setSessionDescription(rs.getString(2));
						session.setSessionDate(new Date(rs.getDate(3).getTime()));
						session.setSlot(rs.getString(4));
						session.setTrainerName(rs.getString(5));
						session.setSkillType(rs.getString(6));
						char[] ch = new char[1];
						try {
							rs.getCharacterStream(7).read(ch);
						} catch (IOException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						session.setIs_completed(ch[0]);
						list.add(session);
					}

					return list;
				}
			});
		
	}

	@Override
	public void enrollUser(int userId, int sessionId) {
		// TODO Auto-generated method stub
		String sql="insert into session_enrollment values("+sessionId+","+userId+")";
		jdbcTemplate.execute(sql);
	}

	@Override
	public List<Session> getRegisteredSessions(int userId) {
		// TODO Auto-generated method stub
		String sql="select * from session_details where session_id in (select session_id from session_enrollment where user_id="+userId+") and session_id not in(select session_id from session_attendance)";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<Session>>() {

			@Override
			public List<Session> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Session> list = new ArrayList<Session>();
				while (rs.next()) {
					Session session = new Session();
					session.setSessionId(rs.getInt(1));
					session.setSessionDescription(rs.getString(2));
					session.setSessionDate(new Date(rs.getDate(3).getTime()));
					session.setSlot(rs.getString(4));
					session.setTrainerName(rs.getString(5));
					session.setSkillType(rs.getString(6));
					char[] ch = new char[1];
					try {
						rs.getCharacterStream(7).read(ch);
					} catch (IOException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					session.setIs_completed(ch[0]);
					list.add(session);
				}

				return list;
			}
		});
		
	}

	@Override
	public void joinSession(int userId, int sessionId) {
		// TODO Auto-generated method stub
		String sql="insert into session_attendance values("+sessionId+","+userId+")";
		jdbcTemplate.execute(sql);
		
	}

	@Override
	public List<Session> getAttendedSessions(int userId) {
		// TODO Auto-generated method stub
		
		String sql="select * from session_details where session_id in (select session_id from session_attendance where user_id="+userId+")";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<Session>>() {

			@Override
			public List<Session> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Session> list = new ArrayList<Session>();
				while (rs.next()) {
					Session session = new Session();
					session.setSessionId(rs.getInt(1));
					session.setSessionDescription(rs.getString(2));
					session.setSessionDate(new Date(rs.getDate(3).getTime()));
					session.setSlot(rs.getString(4));
					session.setTrainerName(rs.getString(5));
					session.setSkillType(rs.getString(6));
					char[] ch = new char[1];
					try {
						rs.getCharacterStream(7).read(ch);
					} catch (IOException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					session.setIs_completed(ch[0]);
					list.add(session);
				}

				return list;
			}
		});
	}

	@Override
	public boolean deleteSession(int sessionId) {
		// TODO Auto-generated method stub
		if(jdbcTemplate.update("delete from session_details where session_id="+sessionId)==1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteTrainer(int trainerId) {
		// TODO Auto-generated method stub
		if(jdbcTemplate.update("delete from trainer_details where trainer_id="+trainerId)==1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteSkillSet(int skillsetId) {
		// TODO Auto-generated method stub
		if(jdbcTemplate.update("delete from skillset_details where skill_id="+skillsetId)==1) {
			return true;
		}
		return false;
	}

	@Override
	public List<User> getRegisteredUsers(int sessionId) {
		// TODO Auto-generated method stub
		String sql="select * from user_details where employee_id in(select user_id from session_enrollment where session_id="+sessionId+")";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<User>>() {

			@Override
			public List<User> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<User> list=new ArrayList<User>();
				while(rs.next()) {
					User user=new User();
					user.setEmployee_id(rs.getInt(1));
					user.setFirstName(rs.getString(2));
					user.setLastName(rs.getString(3));
					user.setEmail(rs.getString(4));
					user.setQuestion1(rs.getString(5));
					user.setQuestion2(rs.getString(6));
					user.setQuestion3(rs.getString(7));
					list.add(user);
				}
				
				return list;
			}});
	}

	@Override
	public List<String> fetchDetails(String email) {
		// TODO Auto-generated method stub
		String sql="select login_details.login_id, user_details.question1,user_details.question2, user_details.question3 from login_details join user_details on login_details.corresponding_id=user_details.employee_id where user_details.email='"+email+"'";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<String>>() {

			@Override
			public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<String> list=new ArrayList<String>();
				while(rs.next()) {
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
				}
				
				return list;
			}});
	}

	@Override
	public void resetPassword(String loginId, String password) {
		// TODO Auto-generated method stub
		jdbcTemplate.execute("update login_details set password='"+password+"' where login_id='"+loginId+"'");
		
	}

	@Override
	public List<Admin> getAdminDetails(int adminId) {
		// TODO Auto-generated method stub
		String sql="select * from admin_details where admin_id="+adminId;
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<Admin>>() {

			@Override
			public List<Admin> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<Admin> list=new ArrayList<Admin>();
				while(rs.next()) {
					Admin admin=new Admin(rs.getString(2),rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6));
					list.add(admin);
				}
				
				return list;
			}});
		
	}

	@Override
	public List<User> getUserDetails(int userId) {
		// TODO Auto-generated method stub
		String sql="select * from user_details where employee_id="+userId;
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<User>>() {

			@Override
			public List<User> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<User> list=new ArrayList<User>();
				while(rs.next()) {
					User user=new User();
					user.setEmployee_id(rs.getInt(1));
					user.setFirstName(rs.getString(2));
					user.setLastName(rs.getString(3));
					user.setEmail(rs.getString(4));
					user.setQuestion1(rs.getString(5));
					user.setQuestion2(rs.getString(6));
					user.setQuestion3(rs.getString(7));
					list.add(user);
				}
				
				return list;
			}});
	}

	@Override
	public List<String> getAdminLoginIds() {
		// TODO Auto-generated method stub
		String sql="select login_id from login_details where type='admin'";
		return jdbcTemplate.query(sql, new ResultSetExtractor<List<String>>() {

			@Override
			public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<String> list=new ArrayList<String>();
				while(rs.next()) {
					list.add(rs.getString(1));
				}
				return list;
			}});
		
	}

	@Override
	public void addAdminLoginId(String loginId) {
		// TODO Auto-generated method stub
		String sql="insert into login_details(login_id,type) values('"+loginId+"','admin')";
		jdbcTemplate.update(sql);
	}
	
	
}
