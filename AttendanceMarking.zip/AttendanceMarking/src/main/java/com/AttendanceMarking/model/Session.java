package com.AttendanceMarking.model;

import java.util.Date;

public class Session {
	private int sessionId;
	private String sessionDescription;
	private Date sessionDate;
	private String slot;
	private String trainerName;
	private String skillType;
	private char is_completed;
	
	//Getters and Setters
	public int getSessionId() {
		return sessionId;
	}
	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}
	public String getSessionDescription() {
		return sessionDescription;
	}
	public void setSessionDescription(String sessionDescription) {
		this.sessionDescription = sessionDescription;
	}
	public Date getSessionDate() {
		return sessionDate;
	}
	public void setSessionDate(Date sessionDate) {
		this.sessionDate = sessionDate;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getTrainerName() {
		return trainerName;
	}
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	public String getSkillType() {
		return skillType;
	}
	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}
	public char getIs_completed() {
		return is_completed;
	}
	public void setIs_completed(char is_completed) {
		this.is_completed = is_completed;
	}
	
	

}
