package com.AttendanceMarking.model;


public class SkillSet {
	private int skillId;
	private String skillType;;
	private String skillDescription;
	
	//Getters and Setters
	public String getSkillType() {
		return skillType;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}
	public String getSkillDescription() {
		return skillDescription;
	}
	public void setSkillDescription(String skillDescription) {
		this.skillDescription = skillDescription;
	}
}
