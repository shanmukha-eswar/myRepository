package com.AttendanceMarking.model;

public class User {
	private int employee_id;
	private String firstName;
	private String lastName;
	private String email;
	private String question1;
	private String question2;
	private String question3;
	
	public User() {
		
	}
	
	public User(String firstName, String lastName, String email, String question1, String question2, String question3) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.question1 = question1;
		this.question2 = question2;
		this.question3 = question3;
	}
	//Getters and Setters
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQuestion1() {
		return question1;
	}
	public void setQuestion1(String question1) {
		this.question1 = question1;
	}
	public String getQuestion2() {
		return question2;
	}
	public void setQuestion2(String question2) {
		this.question2 = question2;
	}
	public String getQuestion3() {
		return question3;
	}
	public void setQuestion3(String question3) {
		this.question3 = question3;
	}
	
	
	

}
