package com.AttendanceMarking.service;

import java.util.Date;
import java.util.List;

import com.AttendanceMarking.model.Admin;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.Trainer;
import com.AttendanceMarking.model.User;

public interface AdminService {
	
	public List<Session> getSessionsOfAdmin(int adminId);
	public List<Trainer> getTrainers();
	public List<Trainer> getAvailableTrainers(String date, String slot, String skill);
	public List<SkillSet> getSkillSets();
	public List<Session> getSessionBySkillType(String skillType);
	public boolean addSession(Session session, int adminId);
	public boolean updateSession(Session session);
	public boolean deleteSession(int sessionId);
	public boolean addTrainer(Trainer trainer);
	public boolean updateTrainer(Trainer trainer);
	public boolean deleteTrainer(int trainerId);
	public boolean addSkillSet(SkillSet skill);
	public boolean deleteSkillSet(int skillsetId);
	public int registerAdmin(Admin admin, String defaultId);
	public void saveLoginDetails(LoginDetails loginDetails);
	public boolean addTrainerAllocation(int trainerId, Date date, String slot);
	public List<User> getRegisteredUsers(int sessionId);
	public List<User> getAttendedUsersOfSession(int sessionId);
	public List<Admin> getAdminDetails(int adminId);
}
