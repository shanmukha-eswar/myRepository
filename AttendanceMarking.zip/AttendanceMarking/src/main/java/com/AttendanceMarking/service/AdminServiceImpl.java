package com.AttendanceMarking.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.AttendanceMarking.dao.Dao;
import com.AttendanceMarking.model.Admin;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.Trainer;
import com.AttendanceMarking.model.User;

@Component
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private Dao dao;

	@Override
	public List<Session> getSessionsOfAdmin(int adminId) {
		// TODO Auto-generated method stub
		return dao.getSessionsOfAdmin(adminId);
	}

	@Override
	public List<Trainer> getTrainers() {
		// TODO Auto-generated method stub
		return dao.getTrainers();
	}
	
	@Override
	public List<Trainer> getAvailableTrainers(String date, String slot, String skill) {
		// TODO Auto-generated method stub
		return dao.getAvailableTrainers(date, slot, skill);
	}

	@Override
	public List<SkillSet> getSkillSets() {
		// TODO Auto-generated method stub
		return dao.getSkillsets();
	}

	@Override
	public boolean addSession(Session session, int adminId) {
		// TODO Auto-generated method stub
		return dao.addSession(session, adminId);
	}

	@Override
	public boolean updateSession(Session session) {
		// TODO Auto-generated method stub
		return dao.updateSession(session);
	}

	@Override
	public boolean addTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		return dao.addTrainer(trainer);
	}

	@Override
	public boolean updateTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		return dao.updateTrainer(trainer);
	}

	@Override
	public boolean addSkillSet(SkillSet skill) {
		// TODO Auto-generated method stub
		return dao.addSkillSet(skill);
	}


	@Override
	public int registerAdmin(Admin admin, String defaultId) {
		// TODO Auto-generated method stub
		return dao.saveAdmin(admin, defaultId);
	}

	@Override
	public void saveLoginDetails(LoginDetails loginDetails) {
		// TODO Auto-generated method stub
		dao.saveLoginDetails(loginDetails);
	}

	@Override
	public boolean addTrainerAllocation(int trainerId, Date date, String slot) {
		// TODO Auto-generated method stub
		return dao.addTrainerAllocation(trainerId, date, slot);
	}

	@Override
	public List<Session> getSessionBySkillType(String skillType) {
		// TODO Auto-generated method stub
		return dao.getSessionBySkillType(skillType);
	}

	@Override
	public boolean deleteSession(int sessionId) {
		// TODO Auto-generated method stub
		return dao.deleteSession(sessionId);
	}

	@Override
	public boolean deleteTrainer(int trainerId) {
		// TODO Auto-generated method stub
		return dao.deleteTrainer(trainerId);
	}

	@Override
	public boolean deleteSkillSet(int skillsetId) {
		// TODO Auto-generated method stub
		return dao.deleteSkillSet(skillsetId);
	}

	@Override
	public List<User> getRegisteredUsers(int sessionId) {
		// TODO Auto-generated method stub
		return dao.getRegisteredUsers(sessionId);
	}

	@Override
	public List<User> getAttendedUsersOfSession(int sessionId) {
		// TODO Auto-generated method stub
		return dao.getAttendedUsersOfSession(sessionId);
	}

	@Override
	public List<Admin> getAdminDetails(int adminId) {
		// TODO Auto-generated method stub
		return dao.getAdminDetails(adminId);
	}

}
