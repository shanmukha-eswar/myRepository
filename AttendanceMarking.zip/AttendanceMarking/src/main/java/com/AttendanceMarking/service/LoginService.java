package com.AttendanceMarking.service;

import java.util.List;

import com.AttendanceMarking.model.LoginDetails;

public interface LoginService {
	
	public List<LoginDetails> getLoginDetails();
	public List<String> fetchDetails(String email);
	public void resetPassword(String loginId, String password);
	public List<String> getAdminLoginIds();
	public void addAdminLoginId(String loginId);

}
