package com.AttendanceMarking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.AttendanceMarking.dao.Dao;
import com.AttendanceMarking.model.LoginDetails;

@Component
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private Dao dao;

	@Override
	public List<LoginDetails> getLoginDetails() {
		// TODO Auto-generated method stub
		return dao.getLoginDetails();
	}

	@Override
	public List<String> fetchDetails(String email) {
		// TODO Auto-generated method stub
		return dao.fetchDetails(email);
	}

	@Override
	public void resetPassword(String loginId, String password) {
		// TODO Auto-generated method stub
		dao.resetPassword(loginId, password);
	}

	@Override
	public List<String> getAdminLoginIds() {
		// TODO Auto-generated method stub
		return dao.getAdminLoginIds();
	}

	@Override
	public void addAdminLoginId(String loginId) {
		// TODO Auto-generated method stub
		dao.addAdminLoginId(loginId);
	}

}
