package com.AttendanceMarking.service;

import java.util.List;

import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.User;

public interface UserService {
	
	public int registerUser(User user);
	public void saveLoginDetails(LoginDetails logindetails);
	public List<Session> getAvailableSessions();
	public List<Session> getSessionBySkillType(String skillType);
	public List<SkillSet> getSkillSets();
	public void enrollUser(int SessionId, int userId);
	public List<Session> getRegisteredSessions(int userId);
	public void joinSession (int userId,int sessionId);
	public List<Session> getAttendedSessions(int userId);
	public List<User> getUserDetails(int userId);

}
