package com.AttendanceMarking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.AttendanceMarking.dao.Dao;
import com.AttendanceMarking.model.LoginDetails;
import com.AttendanceMarking.model.Session;
import com.AttendanceMarking.model.SkillSet;
import com.AttendanceMarking.model.User;

@Component
public class UserServiceImpl implements UserService{
	
	@Autowired
	private Dao dao;

	@Override
	public int registerUser(User user) {
		// TODO Auto-generated method stub
		return dao.saveUser(user);
	}

	@Override
	public void saveLoginDetails(LoginDetails logindetails) {
		// TODO Auto-generated method stub
		dao.saveLoginDetails(logindetails);
		
	}

	@Override
	public List<Session> getAvailableSessions() {
		// TODO Auto-generated method stub
		return dao.getSessions();
	}

	@Override
	public List<Session> getSessionBySkillType(String skillType) {
		// TODO Auto-generated method stub
		return dao.getSessionBySkillType(skillType);
	}

	@Override
	public List<SkillSet> getSkillSets() {
		// TODO Auto-generated method stub
		return dao.getSkillsets();
	}

	@Override
	public void enrollUser(int sessionId, int userId) {
		// TODO Auto-generated method stub
		dao.enrollUser(userId, sessionId);
		
	}

	@Override
	public List<Session> getRegisteredSessions(int userId) {
		// TODO Auto-generated method stub
		return dao.getRegisteredSessions(userId);
	}

	@Override
	public void joinSession(int userId, int sessionId) {
		// TODO Auto-generated method stub
		dao.joinSession(userId, sessionId);
	}

	@Override
	public List<Session> getAttendedSessions(int userId) {
		// TODO Auto-generated method stub
		return dao.getAttendedSessions(userId);
	}

	@Override
	public List<User> getUserDetails(int userId) {
		// TODO Auto-generated method stub
		return dao.getUserDetails(userId);
	}
	
	

}
