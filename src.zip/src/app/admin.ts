export class Admin {
    adminId!:number;
    firstName!:String;
    lastName!:String;
    age!:number;
    gender!:String;
    contactNumber!:String;
    question1!:String;
    question2!:String;
    question3!:String;
}
