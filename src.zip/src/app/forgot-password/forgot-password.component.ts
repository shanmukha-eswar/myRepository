import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login.service';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  email!: String;
  loginId!: String
  password!: String;
  question1!: String;
  question2!: String;
  question3!: String;
  response!: String[];
  view!: boolean[];

  message1!: String;
  message2!: String;
  message3!: String;

  constructor(private service: LoginService, private route: ActivatedRoute, private router: Router) {
    this.view = [true, false, false];
  }

  ngOnInit(): void {
  }

  async fetchDetails() {
    if (this.validateData()) {
      this.response = await this.service.fetchDetails(this.email);
      if (this.response.length == 0) {
        this.message1 = "No account registered on this email.";
        this.loginId="";
        this.view = [true, false, false];
      }
      else {
        this.loginId = this.response[0];
        this.view = [true, false, true];
      }
    }
  }

  forgotPassword() {
    this.view = [false, true, false];
  }

  async validateAndSave() {
    if (this.validateAnswersAndPassword()) {
      if (this.response[1] === this.question1 && this.response[2] === this.question2 && this.response[3] === this.question3) {
        let resp = await this.service.resetPassword(this.loginId, this.password);
        if (resp[0] == "success") {
          window.alert("Password Reset Success");
          this.router.navigate(['']);
        }
      }
    }
  }

  validateData(): boolean {

    //email validations
    if (this.email == null) {
      this.message1 = "email is required";
      return false;
    }

    let count = 0;
    for (let i = 0; i < this.email.length; i++) {
      const ch = this.email.charAt(i);
      if (ch == "@") {
        count++;
      }
    }
    if (count != 1) {
      this.message1 = "Invalid";
      return false;
    }
    if (this.email.slice(-4) != ".com") {
      this.message1 = "Invalid";
      return false;
    }
    this.message1 = "";

    return true;
  }

  validateAnswersAndPassword() {
    //questtions validations
    if (this.question1 == null || this.question2 == null || this.question3 == null) {
      this.message2 = "Please answer all the questions they will help in recovering your credentials";
      return false;
    }
    for (let i = 0; i < this.question1.length; i++) {
      const ch = this.question1.charAt(i);
      if (ch == "0" || ch == "1" || ch == "2" || ch == "3" || ch == "4" || ch == "5" || ch == "6" || ch == "7" || ch == "2" || ch == "9") {
        this.message2 = "Invalid input while answering the questions";
        return false;
      }
    }
    for (let i = 0; i < this.question2.length; i++) {
      const ch = this.question2.charAt(i);
      if (ch == "0" || ch == "1" || ch == "2" || ch == "3" || ch == "4" || ch == "5" || ch == "6" || ch == "7" || ch == "2" || ch == "9") {
        this.message2 = "Invalid input while answering the questions";
        return false;
      }
    }
    for (let i = 0; i < this.question3.length; i++) {
      const ch = this.question3.charAt(i);
      if (ch == "0" || ch == "1" || ch == "2" || ch == "3" || ch == "4" || ch == "5" || ch == "6" || ch == "7" || ch == "2" || ch == "9") {
        this.message2 = "Invalid input while answering the questions";
        return false;
      }
    }
    this.message2 = "";

    //password validations
    if (this.password == null) {
      this.message3 = "Password is Required";
      return false;
    }
    else if (this.password.length < 6) {
      this.message3 = "Minimum length allowed is 6";
      return false;
    }
    let numericCount=0;
    let capCount=0;
    let smallCount=0;
    let specCount=0;
    for (let i = 0; i < this.password.length; i++) {
      const ch = this.password.charAt(i);
      if(ch=="0"||ch=="1"||ch=="2"||ch=="3"||ch=="4"||ch=="5"||ch=="6"||ch=="7"||ch=="8"||ch=="9"){
        numericCount++;
      }
      if(ch=="A" ||ch=="B" ||ch=="C" ||ch=="D" ||ch=="E" ||ch=="F" ||ch=="G" ||ch=="H" ||ch=="I" ||ch=="J" ||ch=="K" ||ch=="L" ||ch=="M" ||ch=="N" ||ch=="O" ||ch=="P" ||ch=="Q" ||ch=="R" ||ch=="S" ||ch=="T" ||ch=="U" ||ch=="V" ||ch=="W" ||ch=="X" ||ch=="Y" ||ch=="Z" ){
        capCount++;
      }
      if(ch=="a" ||ch=="b" ||ch=="c" ||ch=="d" ||ch=="e" ||ch=="f" ||ch=="g" ||ch=="h" ||ch=="i" ||ch=="j" ||ch=="k" ||ch=="l" ||ch=="m" ||ch=="n" ||ch=="o" ||ch=="p" ||ch=="q" ||ch=="r" ||ch=="s" ||ch=="t" ||ch=="u" ||ch=="v" ||ch=="w" ||ch=="x" ||ch=="y" ||ch=="z"){
        smallCount++;
      }
      if(ch=="!" ||ch=="@" ||ch=="&" ||ch=="$" ||ch=="%" ||ch=="*" ||ch=="." ||ch=="?"){
        specCount++;
      }
    }
    if(numericCount==0){
      this.message3="atleast include one digit";
      return false;
    }
    else if(capCount==0){
      this.message3="atleast include one capital letter";
      return false;
    }
    else if(smallCount==0){
      this.message3="atleast include one small letter";
      return false;
    }
    else if(specCount==0){
      this.message3="atleast include one special character (! @ & $ % * . ?)";
      return false;
    }
    this.message3="";

    return true;
  }
}
