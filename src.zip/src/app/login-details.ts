export class LoginDetails {
    loginId!: string;
    password!: String;
    accountType!: String;
    correspondingId!: number;
}
