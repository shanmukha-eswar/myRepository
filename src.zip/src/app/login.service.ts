import { HttpClient } from '@angular/common/http';
import { stringify } from '@angular/compiler/src/util';
import { Injectable } from '@angular/core';
import { LoginDetails } from './login-details';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private loginDetails !: LoginDetails[];

  constructor(private http: HttpClient) {}
    


  async validateLogin(loginId: String,password: String) {
    let result:String="invalid";
    this.loginDetails= await this.http.get<LoginDetails[]>("http://localhost:8080/login").toPromise();
    this.loginDetails.forEach(element => {
      if(loginId===element.loginId && password===element.password){
        sessionStorage.setItem("id",element.correspondingId.toString());
        result=element.accountType;
      }
    });
    return result;
  }

  async ValidateAdminId(adminId:String){
    let result:String="invalid";
    this.loginDetails= await this.http.get<LoginDetails[]>("http://localhost:8080/login").toPromise();
    this.loginDetails.forEach(element=>{
      if(adminId===element.loginId && "admin"===element.accountType){
        sessionStorage.setItem("AdminLoginId",element.loginId);
        result="expected admin";
        if(element.password!=null){
          result="already registered";
        }
      }
    });
    return result;
  }

  async fetchDetails(email:String){
    return this.http.get<String[]>("http://localhost:8080/fetchDetails/"+email).toPromise();
  }

  async resetPassword(loginId:String,password:String){
    return this.http.get<String[]>("http://localhost:8080/resetPassword/"+loginId+"/"+password).toPromise();
  }

  //for super-user purpose
  async getAdminLoginIds(){
    return await this.http.get<String[]>("http://localhost:8080/getAdminLoginIds").toPromise();
  }

  async addAdminLoginId(loginId:String){
    return await this.http.get<String[]>("http://localhost:8080/addAdminLoginId/"+loginId).toPromise();
  }
}
