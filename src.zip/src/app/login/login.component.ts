import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginId!: String;
  password!: String;

  message!: String;
  message1!: String;
  message2!: String;

  constructor(private service: LoginService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    sessionStorage.setItem("allowAdminRegistration","false");
    sessionStorage.removeItem("AdminLoginId");
  }

  async onSubmit() {
    if (this.validateLoginId() && this.validatePassword()) {
      let result = await this.service.validateLogin(this.loginId, this.password);
      switch (result) {
        case "superuser":
          sessionStorage.setItem("isLoggedin", "true");
          this.router.navigate(['superuser']);
          break;
        case "user":
          sessionStorage.setItem("isLoggedin", "true");
          this.router.navigate(['user']);
          break;
        case "admin":
          sessionStorage.setItem("isLoggedin", "true");
          this.router.navigate(['admin']);
          break;
        default:
          this.message = "Invalid Credentials! Try again...";
          this.loginId="";
          this.password="";
          break;
      }
    }
  }

  async test() {
    let input = prompt("Enter Login Id provided by the management: (case-sensitive)");
    if (input != null) {
      let result =await this.service.ValidateAdminId(input);
      switch(result){
        case "invalid":
          sessionStorage.setItem("allowAdminRegistration","false");
          window.alert("You are not expected to be admin");
          break;
        case "already registered":
          window.alert("You are already Registered as Admin!");
          break;
        case "expected admin":
          sessionStorage.setItem("allowAdminRegistration","true");
          console.log("Proceed for registration");
          this.router.navigate(['adminRegistration']);
          break;
      }
    }
  }

  validateLoginId(): boolean {
    if (this.loginId == null) {
      this.message1 = "Login Id is required"
      return false;
    }
    else if (this.loginId.length < 5) {
      this.message1 = "Login Id will be minimum 5 characters"
      return false;
    }
    else {
      this.message1 = "";
    }

    return true;
  }

  validatePassword(): boolean {
    if (this.password == null) {
      this.message2 = "Password is required"
      return false;
    }
    else if (this.password.length < 5) {
      this.message2 = "Password will be minimum 5 characters"
      return false;
    }
    else {
      this.message2 = "";
    }
    return true;
  }
}
