import { Trainer } from "./trainer";

export class Session {
    sessionId!:number;
    sessionDescription!:String;
    sessionDate!:String;
    slot!:String;
    skillType!:String;
    trainer!:Trainer;
    constructor(){
        this.trainer=new Trainer();
    }
}
