import { SkillSet } from './skill-set';

describe('SkillSet', () => {
  it('should create an instance', () => {
    expect(new SkillSet()).toBeTruthy();
  });
});
