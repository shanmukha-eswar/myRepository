export class SkillSet {
    skillId!:number;
    skillType!:String;
    skillDescription!:String;
}
