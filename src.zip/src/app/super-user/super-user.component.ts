import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-super-user',
  templateUrl: './super-user.component.html',
  styleUrls: ['./super-user.component.css']
})
export class SuperUserComponent implements OnInit {

  adminLoginIds!: String[];
  adminLoginId!: String;
  message!:String;
  view!:boolean[];

  constructor(private route: ActivatedRoute, private router: Router, private service: LoginService) {
    this.view=[true,false];
   }

  ngOnInit(): void {
    this.getAdminLoginIds();
  }

  logout() {
    sessionStorage.removeItem("isLoggedin");
    this.router.navigate(['']);
  }

  async getAdminLoginIds() {
    this.adminLoginIds = await this.service.getAdminLoginIds();

  }

  addAdmin() {
    this.view=[false, true]
  }

  async onSubmit() {
    if (this.validateData()) {
      let response = await this.service.addAdminLoginId(this.adminLoginId);
      if (response[0] == "success") {
        window.alert("Admin LoginId added Successfully.");
        this.getAdminLoginIds();
        this.view=[true,false];
      }
    }
  }

  validateData() {
    //loginId validations
    if(this.adminLoginId==null){
      this.message="Login Id is Required";
      return false;
    }
    else if(this.adminLoginId.length<6){
      this.message="Minimum length allowed is 6";
      return false;
    }
    else{
      this.message="";
    }
    return true;
  }
}
