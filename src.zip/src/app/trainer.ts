export class Trainer {
    trainerId!:number;
    trainerName!:String;
    contactNumber!:String;
    email!:String;
    skillType!:String;
}
