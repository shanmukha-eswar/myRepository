import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Session } from '../session';
import { SkillSet } from '../skill-set';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  id: any;
  user!: User;
  availableSessions: any;
  SessionsBySkillType: any;
  enrolledSessions: any;
  attendedSessions: any;
  skills: any;
  skillType!: String;

  constructor(private route: ActivatedRoute, private router: Router, private service: UserService) {
    this.id = sessionStorage.getItem("id");
    this.user = new User();
  }

  ngOnInit(): void {
    if (sessionStorage.getItem("isLoggedin") != "true") {
      window.alert("Please login...");
      this.router.navigate(['']);
    }
    this.getUserDetails();
    this.getAvailableSessions();
    this.getEnrolledSessons();
    this.getAttendedSessions();
    this.getSkills();


  }

  async getUserDetails() {
    let response = await this.service.getUserDetails(this.id);
    response.forEach((element: any) => {
      this.user.firstName = element.firstName;
      this.user.lastName = element.lastName;
    });

  }

  logout() {
    sessionStorage.removeItem("isLoggedin");
    this.router.navigate(['']);
  }

  async getSkills() {
    this.skills = await this.service.getskillsets();
  }

  async getAvailableSessions() {
    this.availableSessions = await this.service.getAvailableSessions();
  }
  async getEnrolledSessons() {
    this.enrolledSessions = await this.service.getEnrolledSessons(this.id);
  }
  async getAttendedSessions() {
    this.attendedSessions = await this.service.getAttendedSessions(this.id);
  }
  async getSessionsBySkillType() {
    this.availableSessions = await this.service.getSessionsBySkillType(this.skillType);

  }

  async enroll(sessionId: number) {
    let response = await this.service.enrollforSession(sessionId, this.id);
    if (response[0] == "success") {
      window.alert("Successfully enrolled.");
      this.getAvailableSessions();
      this.getEnrolledSessons();
    }
  }

  async attend(sessionId: number) {
    let response = await this.service.joinSession(sessionId, this.id);
    this.getEnrolledSessons();
    this.getAttendedSessions();
  }

}
