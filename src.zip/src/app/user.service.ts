import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { waitForAsync } from '@angular/core/testing';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  constructor(private http: HttpClient) { }

  async getUserDetails(userId:String){
    return await this.http.get<String[]>("http://localhost:8080/user/getUserDetails/"+userId).toPromise();
  }

  async registerUser(user: User, loginId: String, password: String) {
    let response=await this.http.get<string[]>("http://localhost:8080/user/userRegistration/" + user.firstName + "/" + user.lastName + "/" + user.email + "/" + loginId + "/" + password + "/" + user.question1 + "/" + user.question2 + "/" + user.question3).toPromise();
    return response[0];
  }

  async getAvailableSessions(){
    return await this.http.get("http://localhost:8080/user/availableSessions").toPromise();
  }

  async getskillsets(){
    let response=await this.http.get("http://localhost:8080/user/getSkillSets").toPromise();
    return response;
  }
  
  async getSessionsBySkillType(skillType:String){
     return await this.http.get("http://localhost:8080/user/getSessionsBySkillType/"+skillType).toPromise();
  }

  async getEnrolledSessons(id:number){
    let response=await this.http.get("http://localhost:8080/user/getEnrolledSessions/"+id).toPromise();
    return response;

  }
  async getAttendedSessions(id:number){
    let response=await this.http.get("http://localhost:8080/user/getAttendedSessions/"+id).toPromise();
    return response;
  }

  async enrollforSession(sessionId:number, userId:number){
    let response=await this.http.get<String[]>("http://localhost:8080/user/enroll/"+sessionId+"/"+userId).toPromise();
    return response;
  }

  async joinSession(sessionId:number, userId:number){
    let response=await this.http.get<String[]>("http://localhost:8080/user/join/"+sessionId+"/"+userId).toPromise();
    return response;
  }
}