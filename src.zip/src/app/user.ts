export class User {
    employeeId!:number;
    firstName!:String;
    lastName!:String;
    email!:String;
    question1!:String;
    question2!:String;
    question3!:String;
}
